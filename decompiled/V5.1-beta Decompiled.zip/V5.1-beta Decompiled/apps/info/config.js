window.apps["info"] = {};
window.apps["info"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Core Functions</h3>	
	</div>
	<div>
		<ul class="list">
			<li><a href="apps/info/settings.html"l>Change Settings</a></li>
			<li><a href="apps/info/info.html">Details on Bunker</a></li>
			<li><a href="apps/info/about.html">Technical bunker://about</a></li>
			<li><a href="apps/info/changes.html">Changelog</a></li>
			<li class="italic">Bunker v5.1-beta</li>
		</ul>
	</div>
</div>`;